#include "header8.h"
/*  TODO:  For this problem, build a function called 'hbw' that takes a pointer to a pointer to a 'struct yyi' that represents the first node in a linked list, and a second pointer to another linked list.  The function should append the list from the second pointer onto the list specified by the first pointer.
Check the header file to find out what the structure definition and function prototype looks like.
*/
	