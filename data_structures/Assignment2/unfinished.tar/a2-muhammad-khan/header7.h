/*  DO NOT MODIFY THIS FILE */

struct nbj;
struct nbj{
	struct nbj * next_nbj;
	unsigned int hpb;
};
void teg(struct nbj *);
	