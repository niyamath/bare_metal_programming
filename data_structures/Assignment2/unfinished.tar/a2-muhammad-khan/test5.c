#include "header5.h"
#include <stdlib.h>
#include <stddef.h>
/*  TODO:  For this problem, build a function called 'erx' that takes a pointer to a 'struct lbt that represents the first node in a linked list.  This function should free all nodes in the list and do so without causing any memory violations.
Check the header file to find out what the structure definition and function prototype looks like.
*/
	
	void erx(struct lbt *q)
	{
		q=(struct lbt *)malloc(sizeof(struct lbt));
		struct lbt *tmp;
		while(q!=NULL)
		{
       tmp=q;
       q=q->next;
       free(tmp);
         }
	}
