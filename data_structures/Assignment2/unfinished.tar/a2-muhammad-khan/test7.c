#include "header7.h"
/*  TODO:  For this problem, build a function called 'teg' that takes a pointer to a 'struct nbj that represents the first node in a linked list.  This function should print all the items in the list in REVERSE order.
Check the header file to find out what the structure definition and function prototype looks like.
*/
	