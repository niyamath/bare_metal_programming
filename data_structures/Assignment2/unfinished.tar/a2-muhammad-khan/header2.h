/*  DO NOT MODIFY THIS FILE */

struct zkz{
	int wvn;
};
void zkf(struct zkz *, int);
	