/*  DO NOT MODIFY THIS FILE */

struct yyi;
struct yyi{
	struct yyi * next_yyi;
	char uhh;
};
void hbw(struct yyi ** pa, struct yyi * b);
	