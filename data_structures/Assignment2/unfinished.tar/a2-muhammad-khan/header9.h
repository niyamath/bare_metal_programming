/*  DO NOT MODIFY THIS FILE */

struct aqh;
struct aqh{
	struct aqh * next_aqh;
	double qaw;
};
struct aqh *bzi(struct aqh *, double);
	