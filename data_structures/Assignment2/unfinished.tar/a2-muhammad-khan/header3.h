/*  DO NOT MODIFY THIS FILE */

struct mkd;
struct mkd{
	struct mkd * next_mkd;
	double jov;
};
struct mkd * jlz(struct mkd *, double);
	