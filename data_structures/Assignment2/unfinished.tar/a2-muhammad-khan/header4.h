/*  DO NOT MODIFY THIS FILE */

struct gnc;
struct gnc{
	struct gnc * next_gnc;
	char cxg;
};
struct gnc * ihy(struct gnc *, struct gnc *);
	