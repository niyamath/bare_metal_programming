REDS="\033[0;31m"
REDE="\033[0m"
SREDS="\[0;31m"
SREDE="\[0m"
if [ $(cat ${1} | wc -l) -ne 0 ];
then
  echo "${REDS}Test Failure for '${1}', here is the difference: ${REDE}";
  echo "${REDS}Test Failure for '${1}'.${REDE}" >> test-results.log;
  cat ${1};
else
  if [ $(cat ${2} | wc -l) -eq 0 ];
    then echo ${REDS}; echo "Valgrind log is empty.  Should at least contain summary"; echo ${REDE};
    echo "${REDS}Test Failure for '${1}'.${REDE}" >> test-results.log;
  elif [ $(cat ${2} | egrep "in use at exit: ([^0])+ " |  wc -l) -ne 0 ]; then 
    cat ${2} | sed "s/in use at exit/${SREDS}in use at exit${SREDE}/g";
    echo "${REDS}Test Failure for '${1}'.${REDE}" >> test-results.log;
  elif [ $(cat ${2} | grep "depends on uninitialised value" |  wc -l) -ne 0 ]; then 
    cat ${2} | sed "s/depends on uninitialised value/${SREDS}depends on uninitialised value${SREDE}/g";
    echo "${REDS}Test Failure for '${1}'.${REDE}" >> test-results.log;
  elif [ $(cat ${2} | grep "Invalid write" |  wc -l) -ne 0 ]; then 
    cat ${2} | sed "s/Invalid write/${SREDS}Invalid write${SREDE}/g";
    echo "${REDS}Test Failure for '${1}'.${REDE}" >> test-results.log;
  elif [ $(cat ${2} | grep "Invalid read" |  wc -l) -ne 0 ]; then
    cat ${2} | sed "s/Invalid read/${SREDS}Invalid read${SREDE}/g";
    echo "${REDS}Test Failure for '${1}'.${REDE}" >> test-results.log;
  elif [ $(cat ${2} | grep "Bad permissions " |  wc -l) -ne 0 ]; then
    cat ${2} | sed "s/Bad permissions/${SREDS}Bad permissions${SREDE}/g";
    echo "${REDS}Test Failure for '${1}'.${REDE}" >> test-results.log;
  else
    echo "\033[0;32mOutput Matches For '${1}' with clean valgrind log ${2}.\033[0m";
    echo "\033[0;32mTest Pass for '${1}'.\033[0m" >> test-results.log;
  fi
fi

