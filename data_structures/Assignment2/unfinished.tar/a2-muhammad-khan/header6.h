/*  DO NOT MODIFY THIS FILE */

struct ncq;
struct ncq{
	struct ncq * next_ncq;
	char ldj;
};
void jyn(struct ncq *);
	