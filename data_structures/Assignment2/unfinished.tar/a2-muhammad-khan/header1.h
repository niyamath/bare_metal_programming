/*  DO NOT MODIFY THIS FILE */

struct tjb{
	int miz;
};
void lio(struct tjb *, int);
	