/*  DO NOT MODIFY THIS FILE */

struct lbt;
struct lbt{
	struct lbt * next_lbt;
	double vvk;
};
void erx(struct lbt *);
	