#include "header9.h"
/*  TODO:  For this problem, build a function called 'bzi' that takes a pointer to a pointer to a 'struct aqh' that represents the first node in a linked list, and a second item that represents the items we want delete.  Return a pointer to a new list where all of the elements in the list that match the second parameter have been deleted.  If the list only contains elements that have the value want to delete, return a null pointer.
Check the header file to find out what the structure definition and function prototype looks like.
*/
	